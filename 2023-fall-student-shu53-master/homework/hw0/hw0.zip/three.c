//Serena Hu
//shu53

//three.c
#include <stdio.h>

int main(void){
  //print"The third prize goes to Pat."
  printf("The third prize goes to Pat.\n");
  return 0;
}

