//Serena Hu
//shu53

//one.c
#include <stdio.h>

int main(void){
  //print "The first prize goes to Jennifer."

  printf("The first prize goes to Jennifer.\n");
  return 0;

}
