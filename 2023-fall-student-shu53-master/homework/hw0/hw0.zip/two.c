//Serena Hu
//shu53

//two.c
#include <stdio.h>

int main(void){
  //print"The second prize goes to Gongqi."
  printf("The second prize goes to Gongqi.\n");
  return 0;
}
